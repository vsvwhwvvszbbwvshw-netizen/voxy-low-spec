# Voxy Low Spec

Düşük donanımlı bilgisayarlar için **Voxy + Sodium** yardımcı modu (Fabric, Minecraft 26.1.2).

## Bu mod ne yapar?

- **Uyumluluk raporu:** Açılışta Voxy, Sodium, seed/dünya üretim modu ve hafif optimizasyon modlarını (Lithium, FerriteCore, ModernFix vb.) tarar. Sonucu `logs/latest.log` ve `config/voxy-low-spec-report.txt` dosyasına yazar.
- **Bellek bekçisi:** Heap kullanımı arka arkaya yüksek kalırsa log'a uyarı yazar. Oyuna müdahale etmez, `System.gc()` çağırmaz.
- **Düşük RAM uyarıları:** Voxy yüklü ve `-Xmx` çok düşükse seni önceden uyarır.
- **Oyunu çökertmez:** Tüm kod `try/catch` içindedir ve Minecraft'in iç sınıflarına dokunmaz.

Voxy'nin lisansı "All Rights Reserved" olduğu için bu proje Voxy ve Sodium'u **içermez ve derleme bağımlılığı olarak kullanmaz**; sadece yüklü olup olmadığına bakar. Voxy, Sodium ve seed üretim modunu kendin Modrinth'ten indirip `mods` klasörüne koymalısın.

## Önemli gerçekler (dürüst not)

- Voxy Extra sayfası önerilen RAM olarak **4 GB (min. 3 GB)** yazıyor. Minecraft 26.x + Voxy LOD'u **1 GB RAM'de stabil çalışması beklenmez**; bu mod RAM'i sihirli şekilde azaltmaz, sorunu görünür yapar ve doğru ayarı bulmana yardım eder.
- 1 GB denemek istersen: render mesafesi 4-6, simülasyon mesafesi 5, Voxy LOD mesafesini en düşük, başka mod/shader yok.
- Sodium 0.9.x ve Voxy için ekran kartın OpenGL 4.5+ desteklemeli.
- Seed/dünya üretim modunun mod kimliğini bilmiyorsan `config/voxy-low-spec.properties` içindeki `integration.extra_mod_ids` satırına ekle.

## Önerilen JVM argümanları (zayıf PC)

Launcher'da "Java arguments" alanına:

```
-Xms512M -Xmx1G -XX:+UseSerialGC -XX:MaxMetaspaceSize=256M -XX:ReservedCodeCacheSize=128M
```

3 GB ayırabiliyorsan `-Xmx3G` yap; Voxy için gerçekçi alt sınır budur.

## Kendi bilgisayarında derleme (isteğe bağlı)

Gereken: **JDK 25**.

```
./gradlew build        # Windows: gradlew.bat build
```

Çıktı: `build/libs/voxy-low-spec-1.0.0.jar` (`-sources.jar` dosyasını kullanma).

---

# GitHub'da yayınlama ve .jar'ı GitHub ile üretme

## 1) Depo (repository) oluştur

1. https://github.com adresinde **New repository** de.
2. Adı: `voxy-low-spec`, **Public** seç. README/.gitignore/license ekleme (zaten var).
3. **Create repository**.

## 2) Dosyaları yükle

Proje klasöründe terminal aç (Git kurulu olmalı):

```
git init
git add .
git commit -m "Ilk surum"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/voxy-low-spec.git
git push -u origin main
```

> Önce şu 3 dosyada `KULLANICI_ADIN` / `Senin GitHub kullanıcı adın` yazan yerleri düzelt:
> `src/main/resources/fabric.mod.json`, `LICENSE`, `README.md`.

## 3) .jar otomatik derlensin (GitHub Actions)

`.github/workflows/build.yml` zaten hazır. `git push` yapınca GitHub otomatik derler:

1. Depoda **Actions** sekmesine gir.
2. Son çalışmaya (yeşil tik ✅) tıkla.
3. Sayfanın altında **Artifacts → voxy-low-spec-jar** indir, zip'in içinden `voxy-low-spec-1.0.0.jar` çıkar.

Kırmızı ❌ çıkarsa çalışmaya tıkla, **Build** adımındaki hata metnini kopyala ve bana gönder; düzeltirim.

## 4) Resmi sürüm (Release) yayınla

```
git tag v1.0.0
git push origin v1.0.0
```

Bu, workflow'u çalıştırır ve `.jar` dosyası depodaki **Releases** sayfasına otomatik eklenir. Oyuncular oradan indirir.

Yeni sürüm için `gradle.properties` içindeki `mod_version` değerini artır (ör. `1.0.1`), commit/push yap ve `v1.0.1` etiketi at.

## 5) Kurulum (oyuncu tarafı)

`mods` klasörüne şunları koy: Fabric Loader, Fabric API, **Sodium**, **Voxy**, `voxy-low-spec-1.0.0.jar` (ve varsa seed üretim modu).

## Yeni Minecraft sürümüne geçiş

https://fabricmc.net/develop adresinden yeni sürümleri öğren, `gradle.properties` içindeki `minecraft_version`, `loader_version`, `fabric_api_version` değerlerini güncelle. Voxy/Sodium'un aynı sürümü desteklediğinden emin ol.
