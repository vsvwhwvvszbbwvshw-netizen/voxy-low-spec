package dev.voxylowspec;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

/**
 * Voxy Low Spec - giris noktasi.
 *
 * Bu sinif Minecraft'in HICBIR ic sinifini kullanmaz. Sadece Fabric Loader ve Java API'si kullanir.
 * Boylece Minecraft surumu degisse bile derleme/calisma hatasi riski minimumdur.
 * Tum is try/catch icindedir: bu mod oyunu asla cokertmez.
 */
public final class VoxyLowSpec implements ModInitializer {

	public static final String MOD_ID = "voxy-low-spec";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		try {
			Path configDir = FabricLoader.getInstance().getConfigDir();

			LowSpecConfig config = LowSpecConfig.loadOrCreate(configDir);
			CompatReport report = CompatReport.build(config);

			report.logToConsole(LOGGER);
			if (config.writeReportFile) {
				report.writeToFile(configDir.resolve("voxy-low-spec-report.txt"), LOGGER);
			}

			if (config.watchdogEnabled) {
				new MemoryWatchdog(config, LOGGER).start();
			}
		} catch (Throwable t) {
			// Hicbir kosulda oyunu cokertme.
			LOGGER.error("[Voxy Low Spec] Startup failed but the game will continue normally.", t);
		}
	}
}
