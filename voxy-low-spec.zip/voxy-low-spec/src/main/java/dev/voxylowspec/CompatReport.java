package dev.voxylowspec;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Acilista yuklu modlari tarar, heap/Java bilgisini toplar ve dusuk donanim icin
 * kisa bir rapor uretir. Rapor hem log'a hem (istege bagli) config klasorune yazilir.
 */
final class CompatReport {

	/** Tavsiye edilen hafif optimizasyon modlari: {id, gosterim adi}. */
	private static final String[][] RECOMMENDED = {
			{"sodium", "Sodium (render optimization)"},
			{"lithium", "Lithium (game logic optimization)"},
			{"ferritecore", "FerriteCore (RAM reduction)"},
			{"modernfix", "ModernFix (RAM + startup)"},
			{"entityculling", "Entity Culling"},
			{"immediatelyfast", "ImmediatelyFast"},
	};

	private final List<String> lines = new ArrayList<>();

	static CompatReport build(LowSpecConfig config) {
		CompatReport r = new CompatReport();
		r.collect(config);
		return r;
	}

	private void collect(LowSpecConfig config) {
		FabricLoader loader = FabricLoader.getInstance();
		Runtime rt = Runtime.getRuntime();
		long maxHeapMb = rt.maxMemory() >> 20;

		lines.add("=== Voxy Low Spec report ===");
		lines.add("Java: " + System.getProperty("java.version") + " (" + System.getProperty("java.vendor") + ")");
		lines.add("CPU threads: " + rt.availableProcessors());
		lines.add("Max heap (-Xmx): " + maxHeapMb + " MB");
		lines.add("Loaded mods: " + loader.getAllMods().size());

		// --- Voxy ---
		ModContainer voxy = find(loader, "voxy");
		if (voxy != null) {
			lines.add("Voxy: FOUND (" + version(voxy) + ")");
		} else {
			lines.add("Voxy: not found (LOD rendering will not be active)");
		}

		// --- Sodium ---
		ModContainer sodium = find(loader, "sodium");
		if (sodium != null) {
			lines.add("Sodium: FOUND (" + version(sodium) + ")");
		} else {
			lines.add("Sodium: not found (Voxy needs Sodium to work)");
		}

		// --- Seed / world generation mods (ids come from the config + a name heuristic) ---
		List<String> genMods = new ArrayList<>();
		for (ModContainer mc : loader.getAllMods()) {
			String id = mc.getMetadata().getId();
			String norm = normalize(id);
			if (norm.equals("voxy") || norm.equals("sodium")) {
				continue;
			}
			boolean configured = false;
			for (String extra : config.extraModIds) {
				if (normalize(extra).equals(norm)) {
					configured = true;
					break;
				}
			}
			boolean heuristic = norm.contains("voxy") && norm.contains("gen");
			if (configured || heuristic) {
				genMods.add(id + " " + version(mc));
			}
		}
		if (genMods.isEmpty()) {
			lines.add("World/seed generation mod: none detected");
		} else {
			lines.add("World/seed generation mod: " + String.join(", ", genMods));
		}

		// --- Recommended optimizers ---
		List<String> missing = new ArrayList<>();
		for (String[] rec : RECOMMENDED) {
			ModContainer found = find(loader, rec[0]);
			if (found == null) {
				missing.add(rec[1]);
			} else {
				lines.add("Optimizer: " + rec[1] + " -> installed (" + version(found) + ")");
			}
		}
		if (!missing.isEmpty()) {
			lines.add("Optional optimizers not installed (use only if a version for your Minecraft exists): "
					+ String.join("; ", missing));
		}

		// --- Warnings ---
		if (voxy != null && maxHeapMb < config.minRecommendedHeapMb) {
			lines.add("WARNING: Max heap is only " + maxHeapMb + " MB. Voxy LOD + chunk data usually needs more. "
					+ "Expect stutter or OutOfMemoryError; keep render distance very low (<= 6) and Voxy LOD distance small.");
		}
		if (voxy != null && sodium == null) {
			lines.add("WARNING: Voxy is installed but Sodium is missing. Install a Sodium build for this Minecraft version.");
		}
		if (maxHeapMb >= 8192 && rt.availableProcessors() <= 2) {
			lines.add("NOTE: Very large heap on a low-core CPU can cause long GC pauses. 2-4 GB is usually enough.");
		}
		lines.add("Recommended JVM args for weak PCs are in the README (SerialGC / small heap profile).");
		lines.add("============================");
	}

	void logToConsole(Logger logger) {
		for (String l : lines) {
			if (l.startsWith("WARNING")) {
				logger.warn("[Voxy Low Spec] {}", l);
			} else {
				logger.info("[Voxy Low Spec] {}", l);
			}
		}
	}

	void writeToFile(Path file, Logger logger) {
		try {
			Files.writeString(file, String.join(System.lineSeparator(), lines) + System.lineSeparator(),
					StandardCharsets.UTF_8);
		} catch (IOException | RuntimeException e) {
			logger.warn("[Voxy Low Spec] Could not write report file: {}", e.toString());
		}
	}

	// ------------------------------------------------------------------ helpers

	/** Mod kimligini normallestirerek bulur: "voxy-worldgen" == "voxy_worldgen" == "VoxyWorldGen". */
	private static ModContainer find(FabricLoader loader, String id) {
		String wanted = normalize(id);
		for (ModContainer mc : loader.getAllMods()) {
			if (normalize(mc.getMetadata().getId()).equals(wanted)) {
				return mc;
			}
		}
		return null;
	}

	private static String normalize(String id) {
		return id.toLowerCase(Locale.ROOT).replace("-", "").replace("_", "");
	}

	private static String version(ModContainer mc) {
		return mc.getMetadata().getVersion().getFriendlyString();
	}
}
