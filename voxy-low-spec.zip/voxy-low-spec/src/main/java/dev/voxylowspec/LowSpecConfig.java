package dev.voxylowspec;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * config/voxy-low-spec.properties dosyasini okur. Dosya yoksa varsayilanlarla olusturur.
 * Bozuk/eksik bir deger varsa varsayilan deger kullanilir (oyun asla cokmez).
 */
final class LowSpecConfig {

	boolean watchdogEnabled = true;
	int intervalSeconds = 30;
	int warnPercent = 85;
	int criticalPercent = 93;
	int consecutiveChecks = 3;
	boolean writeReportFile = true;
	int minRecommendedHeapMb = 1024;
	List<String> extraModIds = new ArrayList<>(List.of("voxy-worldgen", "voxygen", "chunky"));

	private static final String DEFAULT_FILE = """
			# Voxy Low Spec ayarlari
			# Degisiklikten sonra oyunu yeniden baslat.

			# Bellek bekcisi: heap kullanimi uzun sure yuksek kalirsa log'a uyari yazar.
			# (Oyuna mudahale ETMEZ, System.gc() cagirmaz.)
			watchdog.enabled=true
			# Kac saniyede bir kontrol edilsin (5-600)
			watchdog.interval_seconds=30
			# Heap yuzdesi bu degerin ustunde kalirsa UYARI (50-98)
			watchdog.warn_percent=85
			# Heap yuzdesi bu degerin ustunde kalirsa KRITIK uyari (60-99)
			watchdog.critical_percent=93
			# Kac kontrol ust uste yuksek cikarsa uyari verilsin (1-20)
			watchdog.consecutive_checks=3

			# Acilista config/voxy-low-spec-report.txt dosyasi yazilsin mi?
			report.write_file=true
			# Bu MB'in altinda heap ile Voxy uyarisi verilir (256-16384)
			report.min_recommended_heap_mb=1024

			# Ek olarak tespit edilecek mod kimlikleri (virgulle ayir).
			# Seed/dunya uretim modunun kimligini bilmiyorsan buraya yaz.
			integration.extra_mod_ids=voxy-worldgen,voxygen,chunky
			""";

	static LowSpecConfig loadOrCreate(Path configDir) {
		LowSpecConfig cfg = new LowSpecConfig();
		Path file = configDir.resolve("voxy-low-spec.properties");

		try {
			Files.createDirectories(configDir);
			if (!Files.exists(file)) {
				Files.writeString(file, DEFAULT_FILE, StandardCharsets.UTF_8);
				return cfg;
			}
			Properties p = new Properties();
			try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
				p.load(r);
			}
			cfg.watchdogEnabled = bool(p, "watchdog.enabled", cfg.watchdogEnabled);
			cfg.intervalSeconds = integer(p, "watchdog.interval_seconds", cfg.intervalSeconds, 5, 600);
			cfg.warnPercent = integer(p, "watchdog.warn_percent", cfg.warnPercent, 50, 98);
			cfg.criticalPercent = integer(p, "watchdog.critical_percent", cfg.criticalPercent, 60, 99);
			cfg.consecutiveChecks = integer(p, "watchdog.consecutive_checks", cfg.consecutiveChecks, 1, 20);
			cfg.writeReportFile = bool(p, "report.write_file", cfg.writeReportFile);
			cfg.minRecommendedHeapMb = integer(p, "report.min_recommended_heap_mb", cfg.minRecommendedHeapMb, 256, 16384);

			String ids = p.getProperty("integration.extra_mod_ids");
			if (ids != null) {
				List<String> parsed = new ArrayList<>();
				for (String part : ids.split(",")) {
					String s = part.trim();
					if (!s.isEmpty()) {
						parsed.add(s);
					}
				}
				cfg.extraModIds = parsed;
			}
			if (cfg.criticalPercent <= cfg.warnPercent) {
				cfg.criticalPercent = Math.min(99, cfg.warnPercent + 5);
			}
		} catch (IOException | RuntimeException e) {
			VoxyLowSpec.LOGGER.warn("[Voxy Low Spec] Could not read config, using defaults: {}", e.toString());
		}
		return cfg;
	}

	private static boolean bool(Properties p, String key, boolean def) {
		String v = p.getProperty(key);
		if (v == null) {
			return def;
		}
		v = v.trim();
		if (v.equalsIgnoreCase("true")) {
			return true;
		}
		if (v.equalsIgnoreCase("false")) {
			return false;
		}
		return def;
	}

	private static int integer(Properties p, String key, int def, int min, int max) {
		String v = p.getProperty(key);
		if (v == null) {
			return def;
		}
		try {
			int n = Integer.parseInt(v.trim());
			return Math.max(min, Math.min(max, n));
		} catch (NumberFormatException e) {
			return def;
		}
	}
}
