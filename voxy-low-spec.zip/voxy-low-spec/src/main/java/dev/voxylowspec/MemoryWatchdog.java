package dev.voxylowspec;

import org.slf4j.Logger;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;

/**
 * Arka planda dusuk oncelikli bir daemon thread. Heap kullanimini izler ve
 * UST USTE birkac kontrol boyunca yuksek kalirsa log'a uyari yazar.
 *
 * Oyuna mudahale etmez, System.gc() cagirmaz, hicbir Minecraft sinifina dokunmaz.
 */
final class MemoryWatchdog implements Runnable {

	private static final long LOG_COOLDOWN_MS = 5L * 60L * 1000L;

	private final LowSpecConfig config;
	private final Logger logger;

	MemoryWatchdog(LowSpecConfig config, Logger logger) {
		this.config = config;
		this.logger = logger;
	}

	void start() {
		Thread t = new Thread(this, "VoxyLowSpec-Watchdog");
		t.setDaemon(true);
		t.setPriority(Thread.MIN_PRIORITY);
		t.start();
	}

	@Override
	public void run() {
		int highStreak = 0;
		int criticalStreak = 0;
		long lastWarn = 0L;
		long lastCritical = 0L;

		while (!Thread.currentThread().isInterrupted()) {
			try {
				Thread.sleep(config.intervalSeconds * 1000L);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			}

			try {
				long used;
				long max;
				try {
					MemoryUsage u = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
					used = u.getUsed();
					max = u.getMax() > 0 ? u.getMax() : Runtime.getRuntime().maxMemory();
				} catch (Throwable t) {
					Runtime rt = Runtime.getRuntime();
					used = rt.totalMemory() - rt.freeMemory();
					max = rt.maxMemory();
				}
				if (max <= 0) {
					continue;
				}

				int percent = (int) Math.min(100L, (used * 100L) / max);

				highStreak = percent >= config.warnPercent ? highStreak + 1 : 0;
				criticalStreak = percent >= config.criticalPercent ? criticalStreak + 1 : 0;

				long now = System.currentTimeMillis();

				if (criticalStreak >= config.consecutiveChecks && now - lastCritical >= LOG_COOLDOWN_MS) {
					lastCritical = now;
					logger.error("[Voxy Low Spec] CRITICAL: heap {}% ({} / {} MB). Out-of-memory is likely. "
									+ "Lower render distance and Voxy LOD distance, or increase -Xmx.",
							percent, used >> 20, max >> 20);
				} else if (highStreak >= config.consecutiveChecks && now - lastWarn >= LOG_COOLDOWN_MS) {
					lastWarn = now;
					logger.warn("[Voxy Low Spec] WARNING: heap {}% ({} / {} MB) for {} checks in a row. "
									+ "Consider lowering render distance or Voxy LOD distance.",
							percent, used >> 20, max >> 20, highStreak);
				}
			} catch (Throwable t) {
				// Bekci asla oyunu etkilememeli.
				logger.debug("[Voxy Low Spec] Watchdog check failed: {}", t.toString());
			}
		}
	}
}
